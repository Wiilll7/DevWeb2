"""Consulta o ActiveMQ via Jolokia (console web, porta 8161) e imprime
QueueSize / EnqueueCount / DequeueCount e nº de consumidores de um destino."""
import sys, requests
from common import log

def stats(nome, tipo="Queue"):
    mbean = (f"org.apache.activemq:type=Broker,brokerName=localhost,"
             f"destinationType={tipo},destinationName={nome}")
    r = requests.get(f"http://127.0.0.1:8161/api/jolokia/read/{mbean}",
                     auth=("admin", "admin"), headers={"Origin": "http://localhost"}, timeout=10)
    v = r.json().get("value")
    if not v:
        log("STATS", f"{tipo.lower()}://{nome}: destino inexistente")
        return
    log("STATS", f"{tipo.lower()}://{nome}: QueueSize={v['QueueSize']} "
                 f"Enqueue={v['EnqueueCount']} Dequeue={v['DequeueCount']} "
                 f"Consumers={v['ConsumerCount']}")

if __name__ == "__main__":
    stats(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "Queue")
