#!/usr/bin/env bash
# Uso: ./run_experimentos.sh [INTERVALO_s]   (padrão 60 = exigido no enunciado)
# Para um teste rápido: ./run_experimentos.sh 2
set -u
INT="${1:-60}"
cd "$(dirname "$0")"
mkdir -p logs; rm -f logs/*
export AMQP_USER="${AMQP_USER:-admin}" AMQP_PASSWORD="${AMQP_PASSWORD:-admin}"
TO=$(( INT * 6 + 30 ))

echo ">> Subindo ActiveMQ (Docker)"; docker compose up -d
until curl -s -o /dev/null -u admin:admin http://127.0.0.1:8161/; do sleep 2; done; sleep 5
docker compose logs activemq 2>&1 | tail -25 > logs/00_broker_start.log

consumidores() {  # $1=prefixo $2=endereço $3..=flags extras
  local p=$1 a=$2; shift 2
  for i in 1 2 3 4 5; do
    python3 consumer.py --name "$p$i" --address "$a" --timeout "$TO" "$@" >> "logs/$p.log" 2>&1 &
  done
}

echo ">> E1: fila (ponto a ponto, mensagens persistentes)"
consumidores E1 queue://e1; sleep 3
python3 publisher.py --address queue://e1 --interval "$INT" --persistent > logs/E1_publisher.log 2>&1
wait; python3 stats.py e1 > logs/E1_stats.log

echo ">> E2: tópico (fan-out, 5 assinantes recebem a mesma mensagem)"
consumidores E2 topic://e2; sleep 3
python3 publisher.py --address topic://e2 --interval "$INT" > logs/E2_publisher.log 2>&1
wait; python3 stats.py e2 Topic > logs/E2_stats.log

echo ">> E3: persistência x não persistência com reinício do broker"
python3 publisher.py --address queue://e3_persistente --interval 1 --persistent  > logs/E3_pub_persistente.log 2>&1
python3 publisher.py --address queue://e3_transiente  --interval 1               > logs/E3_pub_transiente.log 2>&1
{ python3 stats.py e3_persistente; python3 stats.py e3_transiente; } > logs/E3_stats_antes.log
docker compose restart activemq >/dev/null 2>&1
until curl -s -o /dev/null -u admin:admin http://127.0.0.1:8161/; do sleep 2; done; sleep 5
{ python3 stats.py e3_persistente; python3 stats.py e3_transiente; } > logs/E3_stats_depois.log
python3 consumer.py --name E3P --address queue://e3_persistente --timeout 10 > logs/E3_consumidor_persistente.log 2>&1
python3 consumer.py --name E3T --address queue://e3_transiente  --timeout 10 > logs/E3_consumidor_transiente.log 2>&1

echo ">> E4: assinatura durável x não durável (consumidores offline durante a publicação)"
python3 consumer.py --name DUR --address topic://e4 --durable --timeout 4 > logs/E4_dur_registro.log 2>&1
python3 consumer.py --name NAODUR --address topic://e4 --timeout 4        > logs/E4_naodur_registro.log 2>&1
python3 publisher.py --address topic://e4 --interval 1 --persistent       > logs/E4_publisher.log 2>&1
python3 consumer.py --name DUR --address topic://e4 --durable --timeout 10 > logs/E4_dur_retorno.log 2>&1
python3 consumer.py --name NAODUR --address topic://e4 --timeout 10        > logs/E4_naodur_retorno.log 2>&1

for p in E1 E2; do [ -f logs/$p.log ] && sort logs/$p.log > logs/${p}_consumidores.log && rm logs/$p.log; done
python3 logs2png.py
echo ">> Pronto. Logs e prints em ./logs"
