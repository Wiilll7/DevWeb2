"""Utilidades comuns: URL do broker, credenciais e relógio para logs."""
import os, time

BROKER = os.getenv("AMQP_URL", "amqp://127.0.0.1:5672")
USER = os.getenv("AMQP_USER", "admin")
PASSWORD = os.getenv("AMQP_PASSWORD", "admin")

def ts():
    return time.strftime("%H:%M:%S")

def log(who, msg):
    print(f"[{ts()}] [{who}] {msg}", flush=True)

def conectar(container):
    """Abre conexão AMQP 1.0. Se AMQP_USER for vazio, conecta sem SASL."""
    if USER:
        return container.connect(BROKER, user=USER, password=PASSWORD,
                                 allowed_mechs="PLAIN", allow_insecure_mechs=True,
                                 reconnect=False)
    return container.connect(BROKER, reconnect=False)
